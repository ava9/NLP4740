###CS 4740 PROJECT 2 README

to run, simply use python to run the part1.py script:

in UNIX:
>> python part1.py

in Windows:
>> py part1.py


The output for the phrases and sentences are in the kaggleSubmission1.csv and kaggleSubmission2.csv files respectively