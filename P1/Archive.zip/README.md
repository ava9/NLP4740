# NLP4740

Python 2.7 is used to run this project.
In order to run the demo, please run (on Unix):
>> python p1.py

or on Windows:
>> py p1.py


in the main function, there are multiple functions that can be used:
topicClassification(n)   ||| Here, n is 1, 2, or 3. This classifies the test files based on a unigram, bigram or trigam model
demoSentenceGeneration() ||| This demos sentence generation
performSpellCheck()      ||| Performs spell check and generates the files for the modified test files

The other functions can be run too!
