# NLP4740

In order to run the demo, please run:
>> python p1.py

This will generate 10 unigram sentences and 10 bigram sentences from a random corpus